package com.opsmap.model;

import javafx.scene.paint.Color;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MapData implements Serializable {
    private static final long serialVersionUID = 1L;

    private List<ShapeData> shapes = new ArrayList<>();

    // کلاس داخلی برای ذخیره‌سازی شکل‌ها
    public static class ShapeData implements Serializable {
        private String type; // "LINE", "RECT", "TEXT"
        private double[] points; // مختصات
        private String text; // برای متن
        private double colorR, colorG, colorB; // رنگ
        private double lineWidth;
        private String owner;

        // Constructorها
        public ShapeData() {}

        // Getter و Setter ها
        public String getType() { return type; }
        public void setType(String type) { this.type = type; }

        public double[] getPoints() { return points; }
        public void setPoints(double[] points) { this.points = points; }

        public String getText() { return text; }
        public void setText(String text) { this.text = text; }

        public double getColorR() { return colorR; }
        public void setColorR(double colorR) { this.colorR = colorR; }

        public double getColorG() { return colorG; }
        public void setColorG(double colorG) { this.colorG = colorG; }

        public double getColorB() { return colorB; }
        public void setColorB(double colorB) { this.colorB = colorB; }

        public Color getColor() {
            return Color.color(colorR, colorG, colorB);
        }

        public void setColor(Color color) {
            this.colorR = color.getRed();
            this.colorG = color.getGreen();
            this.colorB = color.getBlue();
        }

        public double getLineWidth() { return lineWidth; }
        public void setLineWidth(double lineWidth) { this.lineWidth = lineWidth; }

        public String getOwner() { return owner; }
        public void setOwner(String owner) { this.owner = owner; }
    }

    // تبدیل shapes به MapData
    public static MapData fromShapes(List<MapShape> shapes) {
        MapData mapData = new MapData();
        for (MapShape shape : shapes) {
            ShapeData sd = new ShapeData();

            if (shape instanceof LineShape) {
                LineShape line = (LineShape) shape;
                sd.setType("LINE");
                sd.setPoints(new double[]{
                        line.getStartX(), line.getStartY(),
                        line.getEndX(), line.getEndY()
                });
            } else if (shape instanceof RectangleShape) {
                RectangleShape rect = (RectangleShape) shape;
                sd.setType("RECT");
                sd.setPoints(new double[]{
                        rect.getX(), rect.getY(),
                        rect.getWidth(), rect.getHeight()
                });
            } else if (shape instanceof TextShape) {
                TextShape textShape = (TextShape) shape;
                sd.setType("TEXT");
                sd.setPoints(new double[]{textShape.getX(), textShape.getY()});
                sd.setText(textShape.getText());
            }

            sd.setColor(shape.getColor());
            sd.setLineWidth(shape.getLineWidth());
            sd.setOwner(shape.getOwner());
            mapData.shapes.add(sd);
        }
        return mapData;
    }

    // تبدیل MapData به shapes
    public List<MapShape> toShapes() {
        List<MapShape> result = new ArrayList<>();
        for (ShapeData sd : shapes) {
            Color color = sd.getColor();
            String owner = sd.getOwner();
            double lineWidth = sd.getLineWidth();

            switch (sd.getType()) {
                case "LINE":
                    double[] linePoints = sd.getPoints();
                    result.add(new LineShape(
                            linePoints[0], linePoints[1],
                            linePoints[2], linePoints[3],
                            color, lineWidth, owner
                    ));
                    break;
                case "RECT":
                    double[] rectPoints = sd.getPoints();
                    result.add(new RectangleShape(
                            rectPoints[0], rectPoints[1],
                            rectPoints[2], rectPoints[3],
                            color, lineWidth, owner
                    ));
                    break;
                case "TEXT":
                    double[] textPoints = sd.getPoints();
                    result.add(new TextShape(
                            textPoints[0], textPoints[1],
                            sd.getText(),
                            color, lineWidth, owner
                    ));
                    break;
            }
        }
        return result;
    }

    // Getter و Setter
    public List<ShapeData> getShapes() { return shapes; }
    public void setShapes(List<ShapeData> shapes) { this.shapes = shapes; }
}