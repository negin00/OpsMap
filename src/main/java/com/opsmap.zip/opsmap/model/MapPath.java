package com.opsmap.model;

import java.util.List;

public class MapPath {
    private List<Double> points;
    private double thickness;
    private String color;

    public MapPath(List<Double> points, double thickness, String color) {
        this.points = points;
        this.thickness = thickness;
        this.color = color;
    }

    public List<Double> getPoints() { return points; }
    public void setPoints(List<Double> points) { this.points = points; }

    public double getThickness() { return thickness; }
    public void setThickness(double thickness) { this.thickness = thickness; }

    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
}
