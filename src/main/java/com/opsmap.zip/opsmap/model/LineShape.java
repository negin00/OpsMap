package com.opsmap.model;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class LineShape extends MapShape {
    private static final long serialVersionUID = 2L;
    private double startX, startY, endX, endY;

    public LineShape(double startX, double startY, double endX, double endY,
                     Color color, double lineWidth, String owner) {
        super(color, lineWidth, owner);
        this.startX = startX;
        this.startY = startY;
        this.endX = endX;
        this.endY = endY;
    }

    @Override
    public void draw(GraphicsContext gc) {
        gc.setStroke(color);
        gc.setLineWidth(lineWidth);
        gc.strokeLine(startX, startY, endX, endY);
    }

    public double getStartX() { return startX; }
    public double getStartY() { return startY; }
    public double getEndX() { return endX; }
    public double getEndY() { return endY; }

    @Override
    public String toNetworkFormat() {
        Color c = getColor();
        return String.format("LINE:%s:%.1f,%.1f,%.1f,%.1f#%.3f,%.3f,%.3f#%.1f",
                owner,
                startX, startY, endX, endY,
                c.getRed(), c.getGreen(), c.getBlue(),
                lineWidth
        );
    }
}