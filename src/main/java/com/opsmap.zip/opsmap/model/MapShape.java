package com.opsmap.model;

import javafx.scene.paint.Color;
import javafx.scene.canvas.GraphicsContext;
import java.io.Serializable;

public abstract class MapShape implements Serializable {
    private static final long serialVersionUID = 1L;

    protected transient Color color;
    protected double lineWidth;
    protected String owner;

    private double colorRed;
    private double colorGreen;
    private double colorBlue;

    public MapShape(Color color, double lineWidth, String owner) {
        this.color = color;
        this.lineWidth = lineWidth;
        this.owner = owner;
        saveColorToFields();
    }

    private void saveColorToFields() {
        if (color != null) {
            this.colorRed = color.getRed();
            this.colorGreen = color.getGreen();
            this.colorBlue = color.getBlue();
        }
    }

    private void loadColorFromFields() {
        this.color = Color.color(colorRed, colorGreen, colorBlue);
    }

    private void writeObject(java.io.ObjectOutputStream out) throws java.io.IOException {
        saveColorToFields();
        out.defaultWriteObject();
    }

    private void readObject(java.io.ObjectInputStream in)
            throws java.io.IOException, ClassNotFoundException {
        in.defaultReadObject();
        loadColorFromFields();
    }

    // ========== متدهای شبکه ==========

    /**
     * تبدیل شکل به رشته برای ارسال در شبکه
     */
    public abstract String toNetworkFormat();

    /**
     * ساخت شکل از رشته شبکه
     */
    public static MapShape fromNetworkFormat(String networkString) {
        try {
            String[] parts = networkString.split(":", 3);
            if (parts.length < 3) return null;

            String type = parts[0];
            String owner = parts[1];
            String data = parts[2];

            String[] dataParts = data.split("#");
            String[] coords = dataParts[0].split(",");
            String[] colorParts = dataParts[1].split(",");
            double lineWidth = Double.parseDouble(dataParts[2]);

            Color color = Color.color(
                    Double.parseDouble(colorParts[0]),
                    Double.parseDouble(colorParts[1]),
                    Double.parseDouble(colorParts[2])
            );

            switch (type) {
                case "LINE":
                    return new LineShape(
                            Double.parseDouble(coords[0]),
                            Double.parseDouble(coords[1]),
                            Double.parseDouble(coords[2]),
                            Double.parseDouble(coords[3]),
                            color, lineWidth, owner
                    );
                case "RECT":
                    return new RectangleShape(
                            Double.parseDouble(coords[0]),
                            Double.parseDouble(coords[1]),
                            Double.parseDouble(coords[2]),
                            Double.parseDouble(coords[3]),
                            color, lineWidth, owner
                    );
                case "TEXT":
                    // برای متن، coords فقط x,y داره
                    String text = dataParts[0];
                    return new TextShape(
                            Double.parseDouble(coords[0]),
                            Double.parseDouble(coords[1]),
                            text, color, lineWidth, owner
                    );
                default:
                    return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // ========== متدهای انتزاعی ==========

    public abstract void draw(GraphicsContext gc);

    // ========== Getter و Setter ==========

    public Color getColor() {
        if (color == null) {
            loadColorFromFields();
        }
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
        saveColorToFields();
    }

    public double getLineWidth() { return lineWidth; }
    public void setLineWidth(double lineWidth) { this.lineWidth = lineWidth; }

    public String getOwner() { return owner; }
    public void setOwner(String owner) { this.owner = owner; }
}