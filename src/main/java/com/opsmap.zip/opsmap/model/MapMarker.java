package com.opsmap.model;

public class MapMarker {
    private double x;
    private double y;
    private String label;
    private String color;

    public MapMarker(double x, double y, String label, String color) {
        this.x = x;
        this.y = y;
        this.label = label;
        this.color = color;
    }

    public double getX() { return x; }
    public void setX(double x) { this.x = x; }

    public double getY() { return y; }
    public void setY(double y) { this.y = y; }

    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }

    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
}