package com.opsmap.model;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;


public class TextShape extends MapShape {
    private static final long serialVersionUID = 4L;
    private double x, y;
    private String text;
    private Font font;

    public TextShape(double x, double y, String text,
                     Color color, double fontSize, String owner) {
        super(color, fontSize, owner);
        this.x = x;
        this.y = y;
        this.text = text;
        this.font = Font.font("Arial", fontSize);
    }

    @Override
    public void draw(GraphicsContext gc) {
        gc.setFill(color);
        gc.setFont(font);
        gc.fillText(text, x, y);
    }


    public double getX() { return x; }
    public double getY() { return y; }
    public String getText() { return text; }
    public Font getFont() { return font; }

    @Override
    public String toNetworkFormat() {
        Color c = getColor();
        return String.format("TEXT:%s:%.1f,%.1f#%s#%.3f,%.3f,%.3f#%.1f",
                owner,
                x, y,
                text,
                c.getRed(), c.getGreen(), c.getBlue(),
                lineWidth
        );
    }
}