package com.opsmap.model;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class RectangleShape extends MapShape {
    private static final long serialVersionUID = 3L;
    private double x, y, width, height;

    public RectangleShape(double x, double y, double width, double height,
                          Color color, double lineWidth, String owner) {
        super(color, lineWidth, owner);
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    @Override
    public void draw(GraphicsContext gc) {
        gc.setStroke(color);
        gc.setLineWidth(lineWidth);
        gc.strokeRect(x, y, width, height);
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public double getWidth() { return width; }
    public double getHeight() { return height; }

    @Override
    public String toNetworkFormat() {
        Color c = getColor();
        return String.format("RECT:%s:%.1f,%.1f,%.1f,%.1f#%.3f,%.3f,%.3f#%.1f",
                owner,
                x, y, width, height,
                c.getRed(), c.getGreen(), c.getBlue(),
                lineWidth
        );
    }
}