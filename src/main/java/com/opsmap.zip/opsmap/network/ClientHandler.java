package com.opsmap.network;

import java.io.*;
import java.net.*;

public class ClientHandler implements Runnable {
    private Socket socket;
    private MapServer server;
    private PrintWriter out;
    private BufferedReader in;
    private String username;

    public ClientHandler(Socket socket, MapServer server) {
        this.socket = socket;
        this.server = server;
        try {
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        try {
            // دریافت نام کاربری
            username = in.readLine();
            System.out.println(username + " به سرور متصل شد.");

            // اطلاع به دیگران
            server.broadcast("USER_JOINED:" + username, this);

            String message;
            while ((message = in.readLine()) != null) {
                System.out.println("از " + username + ": " + message);
                server.broadcast(username + ":" + message, this);
            }
        } catch (IOException e) {
            System.out.println(username + " قطع شد.");
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            server.removeClient(this);
            server.broadcast("USER_LEFT:" + username, this);
        }
    }

    public void sendMessage(String message) {
        out.println(message);
    }
}