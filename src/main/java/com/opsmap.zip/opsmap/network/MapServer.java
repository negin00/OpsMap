package com.opsmap.network;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class MapServer {
    private static final int PORT = 17777;
    private ServerSocket serverSocket;
    private ExecutorService pool = Executors.newFixedThreadPool(10);
    private List<ClientHandler> clients = Collections.synchronizedList(new ArrayList<>());

    public void start() {
        try {
            serverSocket = new ServerSocket(PORT);
            System.out.println("سرور روشن شد. منتظر اتصال کلاینت‌ها روی پورت " + PORT);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("اتصال جدید: " + clientSocket.getInetAddress());

                ClientHandler clientHandler = new ClientHandler(clientSocket, this);
                clients.add(clientHandler);
                pool.execute(clientHandler);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ارسال پیام به همه کلاینت‌ها به جز فرستنده
    public void broadcast(String message, ClientHandler sender) {
        synchronized (clients) {
            for (ClientHandler client : clients) {
                if (client != sender) {
                    client.sendMessage(message);
                }
            }
        }
    }

    // حذف کلاینت قطع شده
    public void removeClient(ClientHandler client) {
        clients.remove(client);
        System.out.println("کلاینت قطع شد. تعداد کلاینت‌ها: " + clients.size());
    }

    public static void main(String[] args) {
        new MapServer().start();
    }
}