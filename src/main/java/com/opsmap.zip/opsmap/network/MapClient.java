package com.opsmap.network;

import java.io.*;
import java.net.*;

public class MapClient {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private String username;
    private MessageListener listener;

    public interface MessageListener {
        void onMessageReceived(String message);
    }

    public MapClient(String username, MessageListener listener) {
        this.username = username;
        this.listener = listener;
    }

    public boolean connect(String serverAddress, int port) {
        try {
            socket = new Socket(serverAddress, port);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            // ارسال نام کاربری
            out.println(username);

            // شروع گوش دادن به پیام‌ها
            new Thread(this::receiveMessages).start();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void receiveMessages() {
        try {
            String message;
            while ((message = in.readLine()) != null) {
                if (listener != null) {
                    listener.onMessageReceived(message);
                }
            }
        } catch (IOException e) {
            System.out.println("ارتباط با سرور قطع شد.");
        }
    }

    public void sendMessage(String message) {
        if (out != null) {
            out.println(message);
        }
    }

    public void disconnect() {
        try {
            if (socket != null) socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}