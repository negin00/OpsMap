package com.opsmap;

import com.opsmap.model.*;
import javafx.scene.paint.Color;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        // 1️⃣ ساخت چند Shape واقعی (قابل رسم)
        List<MapShape> shapes = new ArrayList<>();

        LineShape line = new LineShape(
                0, 0,
                10, 10,
                Color.RED,
                2.0,
                "user1"
        );

        shapes.add(line);

        // 2️⃣ تبدیل Shape ها به MapData (قابل ارسال)
        MapData mapData = MapData.fromShapes(shapes);

        System.out.println("MapData ساخته شد");
        System.out.println("تعداد ShapeData: " + mapData.getShapes().size());

        // 3️⃣ تبدیل MapData دوباره به Shape (قابل رسم)
        List<MapShape> restoredShapes = mapData.toShapes();

        System.out.println("تعداد Shape های بازسازی شده: " + restoredShapes.size());

        // 4️⃣ چاپ جزئیات Shape بازسازی شده
        for (MapShape s : restoredShapes) {
            System.out.println("Type: " + s.getClass().getSimpleName());
            System.out.println("Color: " + s.getColor());
            System.out.println("LineWidth: " + s.getLineWidth());
            System.out.println("Owner: " + s.getOwner());

            if (s instanceof LineShape) {
                LineShape l = (LineShape) s;
                System.out.println(
                        "Line from (" + l.getStartX() + "," + l.getStartY() +
                                ") to (" + l.getEndX() + "," + l.getEndY() + ")"
                );
            }

            System.out.println("------");
        }
    }
}
