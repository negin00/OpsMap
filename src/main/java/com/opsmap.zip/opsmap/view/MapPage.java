package com.opsmap.view;

import com.opsmap.model.*;
import com.opsmap.network.MapClient;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;

public class MapPage {
    private Stage stage;
    private Canvas bgCanvas;
    private Canvas fgCanvas;
    private GraphicsContext bgGC;
    private GraphicsContext fgGC;

    private double startX, startY;
    private boolean drawing = false;
    private String selectedTool = "خط";
    private Color currentColor = Color.BLUE;
    private double currentLineWidth = 3.0;
    private String currentUser = "User1";

    private ObservableList<MapShape> shapes = FXCollections.observableArrayList();
    private ComboBox<String> colorCombo;
    private Slider thicknessSlider;

    // متغیرهای شبکه
    private MapClient mapClient;
    private boolean isConnected = false;
    private Button connectBtn;

    public MapPage(Stage primaryStage) {
        this.stage = primaryStage;
        setupUI();
    }

    private void setupUI() {
        // دکمه‌های ابزار
        Button lineBtn = new Button("خط");
        Button rectBtn = new Button("مستطیل");
        Button textBtn = new Button("متن");
        Button clearBtn = new Button("پاک‌کردن");
        Button deleteMyShapesBtn = new Button("پاک کردن اشکال من");
        Button saveBtn = new Button("ذخیره نقشه");
        Button loadBtn = new Button("بارگیری نقشه");
        connectBtn = new Button("اتصال به سرور");

        // رویداد دکمه‌ها
        lineBtn.setOnAction(e -> selectedTool = "خط");
        rectBtn.setOnAction(e -> selectedTool = "مستطیل");
        textBtn.setOnAction(e -> selectedTool = "متن");

        clearBtn.setOnAction(e -> {
            shapes.clear();
            redrawBackground();
        });

        deleteMyShapesBtn.setOnAction(e -> {
            shapes.removeIf(shape -> shape.getOwner().equals(currentUser));
            redrawBackground();
        });

        saveBtn.setOnAction(e -> saveMap());
        loadBtn.setOnAction(e -> loadMap());
        connectBtn.setOnAction(e -> connectToServer());

        // ComboBox رنگ
        colorCombo = new ComboBox<>(
                FXCollections.observableArrayList("قرمز", "آبی", "سبز", "سیاه", "بنفش")
        );
        colorCombo.setValue("آبی");
        colorCombo.setOnAction(e -> updateCurrentColor());

        // Slider ضخامت
        thicknessSlider = new Slider(1, 10, 3);
        thicknessSlider.setShowTickLabels(true);
        thicknessSlider.setShowTickMarks(true);
        thicknessSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            currentLineWidth = newVal.doubleValue();
        });

        // نوار ابزار
        ToolBar toolbar = new ToolBar(
                lineBtn,
                rectBtn,
                textBtn,
                clearBtn,
                deleteMyShapesBtn,
                saveBtn,
                loadBtn,
                connectBtn,
                new Label(" رنگ:"),
                colorCombo,
                new Label(" ضخامت:"),
                thicknessSlider
        );

        // ایجاد کانواس‌ها
        bgCanvas = new Canvas(800, 600);
        fgCanvas = new Canvas(800, 600);
        bgGC = bgCanvas.getGraphicsContext2D();
        fgGC = fgCanvas.getGraphicsContext2D();

        Pane canvasPane = new Pane(bgCanvas, fgCanvas);
        drawGrid();

        // رویدادهای ماوس
        fgCanvas.setOnMousePressed(e -> {
            startX = e.getX();
            startY = e.getY();
            drawing = true;
        });

        fgCanvas.setOnMouseReleased(e -> {
            if (!drawing) return;

            double endX = e.getX();
            double endY = e.getY();

            if (selectedTool.equals("خط")) {
                LineShape line = new LineShape(startX, startY, endX, endY,
                        currentColor, currentLineWidth, currentUser);
                shapes.add(line);
                sendShapeToNetwork(line);
                redrawBackground();
            } else if (selectedTool.equals("مستطیل")) {
                RectangleShape rect = new RectangleShape(
                        Math.min(startX, endX),
                        Math.min(startY, endY),
                        Math.abs(endX - startX),
                        Math.abs(endY - startY),
                        currentColor, currentLineWidth, currentUser
                );
                shapes.add(rect);
                sendShapeToNetwork(rect);
                redrawBackground();
            } else if (selectedTool.equals("متن")) {
                TextInputDialog dialog = new TextInputDialog("متن خود را وارد کنید");
                dialog.setTitle("ورود متن");
                dialog.setHeaderText("متن مورد نظر برای قرارگیری روی نقشه");
                dialog.setContentText("متن:");

                dialog.showAndWait().ifPresent(inputText -> {
                    if (!inputText.trim().isEmpty()) {
                        TextShape textShape = new TextShape(
                                startX, startY,
                                inputText,
                                currentColor,
                                currentLineWidth * 3,
                                currentUser
                        );
                        shapes.add(textShape);
                        sendShapeToNetwork(textShape);
                        redrawBackground();
                    }
                });
            }

            fgGC.clearRect(0, 0, fgCanvas.getWidth(), fgCanvas.getHeight());
            drawing = false;
        });

        // پیش‌نمایش هنگام کشیدن
        fgCanvas.setOnMouseDragged(e -> {
            if (!drawing) return;

            fgGC.clearRect(0, 0, fgCanvas.getWidth(), fgCanvas.getHeight());
            double currentX = e.getX();
            double currentY = e.getY();

            if (selectedTool.equals("خط")) {
                fgGC.setStroke(currentColor);
                fgGC.setLineWidth(1);
                fgGC.setLineDashes(5);
                fgGC.strokeLine(startX, startY, currentX, currentY);
                fgGC.setLineDashes(null);
            } else if (selectedTool.equals("مستطیل")) {
                fgGC.setStroke(currentColor);
                fgGC.setLineWidth(1);
                fgGC.setLineDashes(5);
                fgGC.strokeRect(
                        Math.min(startX, currentX),
                        Math.min(startY, currentY),
                        Math.abs(currentX - startX),
                        Math.abs(currentY - startY)
                );
                fgGC.setLineDashes(null);
            }
        });

        // نوار کناری
        ListView<String> userList = new ListView<>();
        userList.setItems(FXCollections.observableArrayList(
                "کاربر ۱ (آنلاین)",
                "کاربر ۲ (آنلاین)",
                "کاربر ۳ (آفلاین)"
        ));

        TextArea commandArea = new TextArea();
        commandArea.setPromptText("دستورات متنی...");

        VBox sidebar = new VBox(10,
                new Label("کاربران آنلاین:"),
                userList,
                new Label("دستورات:"),
                commandArea,
                new Label("اشکال: " + shapes.size())
        );
        sidebar.setPrefWidth(200);

        // چیدمان نهایی
        BorderPane root = new BorderPane();
        root.setTop(toolbar);
        root.setCenter(canvasPane);
        root.setRight(sidebar);

        Scene scene = new Scene(root, 1000, 700);
        stage.setTitle("OpsMap - نقشه عملیاتی (کاربر: " + currentUser + ")");
        stage.setScene(scene);
        stage.show();
    }

    // ========== متدهای کمکی ==========

    private void updateCurrentColor() {
        String colorName = colorCombo.getValue();
        switch (colorName) {
            case "قرمز": currentColor = Color.RED; break;
            case "آبی": currentColor = Color.BLUE; break;
            case "سبز": currentColor = Color.GREEN; break;
            case "سیاه": currentColor = Color.BLACK; break;
            case "بنفش": currentColor = Color.PURPLE; break;
            default: currentColor = Color.BLUE;
        }
    }

    private void redrawBackground() {
        bgGC.clearRect(0, 0, bgCanvas.getWidth(), bgCanvas.getHeight());
        drawGrid();
        for (MapShape shape : shapes) {
            shape.draw(bgGC);
        }
    }

    private void drawGrid() {
        bgGC.setStroke(Color.LIGHTGRAY);
        bgGC.setLineWidth(0.5);
        for (int x = 0; x < bgCanvas.getWidth(); x += 20) {
            bgGC.strokeLine(x, 0, x, bgCanvas.getHeight());
        }
        for (int y = 0; y < bgCanvas.getHeight(); y += 20) {
            bgGC.strokeLine(0, y, bgCanvas.getWidth(), y);
        }

        bgGC.setFill(Color.BLACK);
        bgGC.fillText("نقشه عملیاتی OpsMap", 10, 20);
        bgGC.fillText("کاربر: " + currentUser, 10, 40);
        bgGC.fillText("تعداد اشکال: " + shapes.size(), 10, 60);
        bgGC.fillText("وضعیت شبکه: " + (isConnected ? "متصل" : "قطع"), 10, 80);

        bgGC.setStroke(Color.DARKGRAY);
        bgGC.setLineWidth(1);
        bgGC.strokeRect(0, 0, bgCanvas.getWidth(), bgCanvas.getHeight());
    }

    // ========== متدهای شبکه ==========

    private void connectToServer() {
        if (isConnected) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("قبلاً به سرور متصل شده‌اید.");
            alert.show();
            return;
        }

        TextInputDialog dialog = new TextInputDialog("localhost");
        dialog.setTitle("اتصال به سرور");
        dialog.setHeaderText("آدرس سرور را وارد کنید");
        dialog.setContentText("آدرس:");

        dialog.showAndWait().ifPresent(address -> {
            mapClient = new MapClient(currentUser, this::handleNetworkMessage);
            boolean connected = mapClient.connect(address, 17777);

            if (connected) {
                isConnected = true;
                connectBtn.setText("قطع اتصال");
                connectBtn.setOnAction(e -> disconnectFromServer());

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("به سرور متصل شدید.");
                alert.show();
                redrawBackground();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("اتصال به سرور ناموفق بود.");
                alert.show();
            }
        });
    }

    private void disconnectFromServer() {
        if (mapClient != null) {
            mapClient.disconnect();
            mapClient = null;
            isConnected = false;
            connectBtn.setText("اتصال به سرور");
            connectBtn.setOnAction(e -> connectToServer());

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("از سرور قطع شدید.");
            alert.show();
            redrawBackground();
        }
    }

    private void handleNetworkMessage(String message) {
        Platform.runLater(() -> {
            System.out.println("پیام دریافتی از شبکه: " + message);

            if (message.startsWith("USER_JOINED:")) {
                String joinedUser = message.substring(12);
                System.out.println("کاربر جدید: " + joinedUser);

            } else if (message.startsWith("USER_LEFT:")) {
                String leftUser = message.substring(10);
                System.out.println("کاربر خارج شد: " + leftUser);

            } else if (message.contains(":DRAW:")) {
                processDrawingCommand(message);
            }
        });
    }

    private void processDrawingCommand(String message) {
        try {
            String[] parts = message.split(":", 3);
            if (parts.length < 3) return;

            String sender = parts[0];
            String drawCommand = parts[1] + ":" + parts[2];

            if (!sender.equals(currentUser)) {
                String shapeData = drawCommand.substring(5);
                MapShape shape = MapShape.fromNetworkFormat(shapeData);
                if (shape != null) {
                    shapes.add(shape);
                    redrawBackground();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void sendShapeToNetwork(MapShape shape) {
        if (mapClient != null && isConnected) {
            String message = "DRAW:" + shape.toNetworkFormat();
            mapClient.sendMessage(message);
        }
    }

    // ========== Save/Load ==========

    private void saveMap() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("ذخیره نقشه");
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("فایل نقشه OpsMap", "*.opsmap")
        );
        fileChooser.setInitialFileName("map_" + System.currentTimeMillis() + ".opsmap");

        File file = fileChooser.showSaveDialog(stage);
        if (file != null) {
            try (ObjectOutputStream oos = new ObjectOutputStream(
                    new FileOutputStream(file))) {

                MapData mapData = MapData.fromShapes(shapes);
                oos.writeObject(mapData);

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("نقشه با موفقیت ذخیره شد: " + file.getName());
                alert.show();

            } catch (IOException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("خطا در ذخیره فایل: " + ex.getMessage());
                alert.show();
            }
        }
    }

    private void loadMap() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("بارگیری نقشه");
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("فایل نقشه OpsMap", "*.opsmap")
        );

        File file = fileChooser.showOpenDialog(stage);
        if (file != null) {
            try (ObjectInputStream ois = new ObjectInputStream(
                    new FileInputStream(file))) {

                MapData mapData = (MapData) ois.readObject();
                shapes.clear();
                shapes.addAll(mapData.toShapes());
                redrawBackground();

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("نقشه با موفقیت بارگیری شد: " + file.getName());
                alert.show();

            } catch (IOException | ClassNotFoundException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("خطا در بارگیری فایل: " + ex.getMessage());
                alert.show();
            }
        }
    }

}